Access API for the Management Information Tree.


